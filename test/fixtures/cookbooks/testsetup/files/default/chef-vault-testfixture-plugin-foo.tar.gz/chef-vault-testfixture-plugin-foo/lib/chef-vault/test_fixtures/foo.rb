class ChefVault
  class TestFixtures
    class Foo
      def test
        { 'foo' => 1 }
      end
    end
  end
end
